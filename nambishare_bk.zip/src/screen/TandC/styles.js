import { StyleSheet } from 'react-native'
export const styles = StyleSheet.create({
    container: {
        flex: 1,
        
       
        backgroundColor: 'white',
        height: '100%',
        paddingTop:50,
        paddingLeft:20
        // borderWidth: 1
    },
  
})